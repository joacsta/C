/******************************************************************************
Aluno(a): Jo�o Victor Tavares da Costa
Matr�cula: 231012254
Declaro que eu sou o(a) autor(a) deste trabalho e que o c�digo n�o foi copiado
de outra pessoa nem repassado para algu�m. Estou ciente de que poderei sofrer
penaliza��es na avalia��o em caso de detec��o de pl�gio.
*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h> //inclusao de bibliotecas
#include <locale.h>
#include <ctype.h>

#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H // Definicoes de biblioteca

#define OPCAO1_CONSULTAR_MINIUSINA 1
#define OPCAO2_CONSULTAR_CONSUMIDOR 2
#define OPCAO3_LISTAGEM_MINIUSINAS 3
#define OPCAO4_LISTAGEM_MINIUSINAS_OPERACAO_DECRESCENTE 4
#define OPCAO5_LISTAGEM_RAS_ORDEM_DESCRESCENTE_QUANTIDADE_MINIUSINAS 5
#define OPCAO6_LISTAGEM_RAS_ORDEM_CRESCENTE_CONTRATOS 6 //opcoes do menu
#define OPCAO7_LISTAGEM_RAS_ORDEM_DESCRESCENTE_CAPACIDADE_GERACAO 7
#define OPCAO8_LISTAGEM_RAS_ORDEM_DESCRESCENTE_PERCENTUAL_ENERGIA_DISPONIVEL 8
#define OPCAO9_SAIR 9

#define TAM_CNPJ 19
#define TAM_CPF 15
#define TAM_NOME_MINIUSINA 100 //tamanho permitido de caracteres
#define TAM_ENERGIA_MINIUSINA 1000000 //OPCAO1_CONSULTAR_MINIUSINA
#define TAM_RA_MINIUSINA 99
#define TAM_STATUS_MINIUSINA 10

#define TAM_ID_CONTRATO 3 //tamanho permitido de caracteres
#define TAM_ID_CONSUMIDOR 19 //OPCAO1_CONSULTAR_MINIUSINA e OPCAO2_CONSULTAR_CONSUMIDOR
#define TAM_DATA_CONTRATO 11

#define TAM_NOME_CONSUMIDOR 100 //OPCAO2_CONSULTAR_CONSUMIDOR
//tamanho permitido de caracteres

struct usina //struct destinado a primeira opcao
{
  char cnpj[TAM_CNPJ];
  char nome[TAM_NOME_MINIUSINA];
  char energia[TAM_ENERGIA_MINIUSINA];
  char idra[TAM_RA_MINIUSINA];
  char status[TAM_STATUS_MINIUSINA];
};

struct contrato //struct destinada para a primeira opcao, se estiver disponivel nos arquivos
{
  char idcontrato[TAM_ID_CONTRATO];
  char idconsumidor[TAM_ID_CONSUMIDOR];
  char cnpj[TAM_CNPJ];
  char inicio_data[TAM_DATA_CONTRATO];
  char energiacontratada[TAM_ENERGIA_MINIUSINA];
};

struct consumidor1 //struct destinado para opcao 2 caso o usu�rio selecione a opcao CNPJ
{
  char cnpj[TAM_CNPJ];
  char nome[TAM_NOME_CONSUMIDOR];
  char idra[TAM_RA_MINIUSINA];
};

struct consumidor2 //struct destinado para opcao 2 caso o usu�rio selecione a opcao CPF
{
  char cpf[TAM_CPF];
  char nome[TAM_NOME_CONSUMIDOR];
  char idra[TAM_RA_MINIUSINA];
};
struct lista_usina {
  char cap_energia[TAM_ENERGIA_MINIUSINA];
  char nome[TAM_NOME_MINIUSINA];
  char cnpj[TAM_CNPJ];
  char idra[TAM_RA_MINIUSINA];
  char status[TAM_STATUS_MINIUSINA];
};

void selectionSort(struct lista_usina usinas[], int n) {
  int i, j, max_idx;
  struct lista_usina temp;

  for (i = 0; i < n - 1; i++) {
    max_idx = i;
    for (j = i + 1; j < n; j++) {
      // Converte as capacidades de energia para valores inteiros para compara��o
      int cap1 = atoi(usinas[j].cap_energia);
      int cap2 = atoi(usinas[max_idx].cap_energia);
      if (cap1 > cap2) {
        max_idx = j;
      }
    }
    if (max_idx != i) {
      temp = usinas[i];
      usinas[i] = usinas[max_idx];
      usinas[max_idx] = temp;
    }
  }
}

void opcao4() {
  setlocale(LC_CTYPE, "Portuguese");
  struct lista_usina usinas[100]; // Suponha que haja no m�ximo 100 usinas
  FILE *arquivo_usina;

  arquivo_usina = fopen("miniusinas.csv", "r");
  if (arquivo_usina == NULL) {
    printf("N�o foi poss�vel abrir o arquivo.\n");
    return;
  }

  printf("Voc� selecionou a OP��O 4, 'Listar as miniusinas em opera��o por ordem decrescente de capacidade de gera��o de energia'.\n");
  printf("Por favor, aguarde...\n");
  system("pause");

  int count = 0;
  while (fscanf(arquivo_usina, "%[^;];%[^;];%[^;];%[^;];%[^\n]\n", usinas[count].cnpj,
                usinas[count].nome,
                usinas[count].cap_energia,
                usinas[count].idra,
                usinas[count].status) != EOF) {
    count++;
  }

  // Aplica o algoritmo de ordena��o selection sort
  selectionSort(usinas, count);

  printf("Miniusinas ordenadas por ordem decrescente de capacidade de gera��o de energia:\n\n");
  for (int i = count - 1; i >= 0; i--) {
    printf("\tCapacidade de Energia: %s\n", usinas[i].cap_energia);
    printf("\tNome: %s\n", usinas[i].nome);
    printf("\tCNPJ: %s\n", usinas[i].cnpj);
    printf("\tRA da Usina: %s\n", usinas[i].idra);
    printf("\tStatus: %s\n", usinas[i].status);
    printf("\n");
  }

  // Fecha o arquivo
  fclose(arquivo_usina);

  printf("Deseja continuar? Se sim, por favor, digite outra op��o.\n");
}

void consulta_e_validacao(const char * str) { //opcao 1
  setlocale(LC_CTYPE, "Portuguese");
  struct usina usina_cadastrada;
  char cnpj_consulta[TAM_CNPJ];
  int encontrei_usina = 0;
  FILE * arquivo_usina;

  printf("\nOP��O 1, 'Consultar miniusina cadastrada' selecionada.\n");
  system("pause");
  printf("Por favor, digite um CNPJ para realizar a opera��o: ");
  scanf(" %[^\n]", cnpj_consulta);

  arquivo_usina = fopen("miniusinas.csv", "r");

  if (arquivo_usina != NULL) {
    while (!feof(arquivo_usina)) {
      fscanf(arquivo_usina, "%[^;];%[^;];%[^;];%[^;];%[^\n]\n",
        usina_cadastrada.cnpj,
        usina_cadastrada.nome,
        usina_cadastrada.energia,
        usina_cadastrada.idra,
        usina_cadastrada.status);

      if (strcmp(cnpj_consulta, usina_cadastrada.cnpj) == 0) {
        printf("\nAQUI EST�O AS SEGUINTES INFORMA��ES SOLICITADAS.\n");
        printf("\nCNPJ: %s\n", usina_cadastrada.cnpj);
        printf("Nome da Usina: %s\n", usina_cadastrada.nome);
        printf("Capacidade de energia: %s\n", usina_cadastrada.energia);
        printf("Regi�o Administrativa: %s\n", usina_cadastrada.idra);
        printf("Status: %s", usina_cadastrada.status);
        encontrei_usina = 1;
      }
    }
    if (encontrei_usina == 0) {
      printf("\nAVISO!\nN�o foi encontrada nenhuma usina com o CNPJ: %s.", cnpj_consulta);
    }
  } else {
    printf("ERRO, N�O FOI POSS�VEL ABRIR O ARQUIVO.\n");
  }

  FILE * arquivo_contrato;
  struct contrato contrato_cadastrado;
  arquivo_contrato = fopen("contratos.csv", "r");
  int encontrei_contrato = 0;

  if (arquivo_contrato != NULL) {
    while (!feof(arquivo_contrato)) {
      fscanf(arquivo_contrato, "%[^;];%[^;];%[^;];%[^;];%[^\n]\n",
        contrato_cadastrado.idcontrato,
        contrato_cadastrado.idconsumidor,
        contrato_cadastrado.cnpj,
        contrato_cadastrado.inicio_data,
        contrato_cadastrado.energiacontratada);

      if (strcmp(cnpj_consulta, contrato_cadastrado.cnpj) == 0) {
        printf("\nID Contrato: %s\n", contrato_cadastrado.idcontrato);
        printf("ID Consumidor: %s\n", contrato_cadastrado.idconsumidor);
        printf("Data: %s\n", contrato_cadastrado.inicio_data);

        encontrei_contrato = 1;
      }
    }
    if (encontrei_contrato == 0) {
      printf("\nNenhum contrato identificado com o CNPJ: %s.\n", cnpj_consulta);
    }
  } else {
    printf("\nERRO, N�O FOI POSS�VEL ABRIR O ARQUIVO.\n");
  }

  int tamanho = strlen(str);
  int j = 0; //DECLARACAO DE VARIAVEIS PARA A VALIDACAO DE CNPJ
  int icnpj[TAM_CNPJ];
  int i, digito1, digito2, result1, result2, valor, somador = 0;

  for (int i = 0; i < tamanho; i++) {
    if (isdigit(str[i])) {
      cnpj_consulta[j] = str[i];
      j++;
    }
  }
  cnpj_consulta[j] = '\0';

  for (i = 0; i < 14; i++) {
    icnpj[i] = cnpj_consulta[i] - '0';
  }

  // C�lculo do primeiro d�gito
  somador = icnpj[0] * 5 + icnpj[1] * 4 + icnpj[2] * 3 + icnpj[3] * 2 +
    icnpj[4] * 9 + icnpj[5] * 8 + icnpj[6] * 7 + icnpj[7] * 6 +
    icnpj[8] * 5 + icnpj[9] * 4 + icnpj[10] * 3 + icnpj[11] * 2;

  result1 = somador % 11;
  digito1 = (result1 < 2) ? 0 : 11 - result1;

  // C�lculo do segundo d�gito
  somador = icnpj[0] * 6 + icnpj[1] * 5 + icnpj[2] * 4 + icnpj[3] * 3 +
    icnpj[4] * 2 + icnpj[5] * 9 + icnpj[6] * 8 + icnpj[7] * 7 +
    icnpj[8] * 6 + icnpj[9] * 5 + icnpj[10] * 4 + icnpj[11] * 3 + icnpj[12] * 2;
  valor = (somador / 11) * 11;
  result2 = somador - valor;
  digito2 = (result2 < 2) ? 0 : 11 - result2;

  if (digito1 == icnpj[12] && digito2 == icnpj[13]) {
    printf("CNPJ: v�lido\n\nCaso queira continuar, selecione outra op��o.");
  } else {
    printf("CNPJ: inv�lido!\n\nCaso queira continuar, selecione outra op��o.");
  }

}

void consumidor_cpf(const char * str) { //destinado a operacao da op��o 2 com CPF
  setlocale(LC_CTYPE, "Portuguese");
  struct consumidor2 consumidor_cad2;
  char cpf_consulta[TAM_CPF]; //declaracao de variaveis
  int encontrei_consumidor = 0;
  FILE * arquivo_consumidor;

  printf("\nOP��O 2 COM CPF, 'Consultar consumidor cadastrado' selecionada.\n");
  system("pause");
  printf("Por favor, digite um CPF para realizar a opera��o: ");
  scanf(" %[^\n]", cpf_consulta); //escaneamento da entrada

  arquivo_consumidor = fopen("consumidores.csv", "r"); //leitura do arquivo
  if (arquivo_consumidor != NULL) { //caso arquivo seja diferente de 'nulo' o arquivo passar� por um escaneamento
    while (!feof(arquivo_consumidor)) { //feof retorna um valor diferente de zero se uma opera��o de leitura tentou ler ap�s o final do arquivo.
      fscanf(arquivo_consumidor, "%[^;];%[^;];%[^\n]\n", consumidor_cad2.cpf, //escaneamento "separados" por ponto e v�rgula
        consumidor_cad2.nome,
        consumidor_cad2.idra);
      if (strcmp(cpf_consulta, consumidor_cad2.cpf) == 0) { //caso n�o haja nenhuma obje��o, o processo continuar�
        printf("\nAQUI EST�O AS SEGUINTES INFORMA��ES SOLICITADAS.");
        printf("\n\nCPF do Consumidor: %s\n", consumidor_cad2.cpf); //dados que aparecer�o no STRUCT
        printf("Nome: %s\n", consumidor_cad2.nome);
        printf("ID Regi�o Administrativa: %s\n", consumidor_cad2.idra);
        encontrei_consumidor = 1;
      }
    }
    if (encontrei_consumidor == 0) { //caso a vari�vel desligue
      printf("\nAVISO!\nN�o foi encontrado(a) nenhum(a) consumidor(a) com o CPF: %s.\n", cpf_consulta);
    }
  } else {
    printf("ERRO, N�O FOI POSS�VEL ABRIR O ARQUIVO.");
  }

  int tamanho = strlen(str);
  int j = 0; //DECLARACAO DE VARIAVEIS PARA A VALIDACAO DE CPF
  int icpf[TAM_CPF];
  int i, result1, result2, somador = 0;

  for (int i = 0; i < tamanho; i++) {
    if (isdigit(str[i])) {
      cpf_consulta[j] = str[i];
      j++;
    }
  }
  cpf_consulta[j] = '\0'; //fun��o para extrair n�meros da digitacao do cpf com pontos e v�rgula

  for (i = 0; i < 11; i++) {
    icpf[i] = cpf_consulta[i] - '0'; //come�o da valida��o
  }

  // C�lculo do primeiro d�gito
  somador = icpf[0] * 10 + icpf[1] * 9 + icpf[2] * 8 + icpf[3] * 7 +
    icpf[4] * 6 + icpf[5] * 5 + icpf[6] * 4 + icpf[7] * 3 +
    icpf[8] * 2;

  result1 = (somador % 11 < 2) ? 0 : 11 - (somador % 11);

  // C�lculo do segundo d�gito
  somador = icpf[0] * 11 + icpf[1] * 10 + icpf[2] * 9 + icpf[3] * 8 +
    icpf[4] * 7 + icpf[5] * 6 + icpf[6] * 5 + icpf[7] * 4 +
    icpf[8] * 3 + result1 * 2;

  result2 = (somador % 11 < 2) ? 0 : 11 - (somador % 11);

  if (result1 == icpf[9] && result2 == icpf[10]) {
    printf("CPF: v�lido\n\nCaso queira continuar, selecione outra op��o.");
  } else {
    printf("CPF: inv�lido!\n\nCaso queira continuar, selecione outra op��o.");
  }
}

void consumidor_cnpj(const char * str) { //destinado a opera��o da op��o 2 com CNPJ
  setlocale(LC_CTYPE, "Portuguese");
  struct consumidor1 consumidor_cad; //void para a opcao 2, com a opcao de validacao apenas para cnpj
  char cnpj_consulta[TAM_CNPJ]; //declaracao de vari�veis
  int encontrei_consumidor = 0;
  FILE * arquivo_consumidor;

  printf("\nOP��O 2 COM CNPJ, 'Consultar consumidor cadastrado' selecionada.\n");
  system("pause");
  printf("Por favor, digite um CNPJ para realizar a opera��o: ");
  scanf(" %[^\n]", cnpj_consulta); //escaneamento da entrada

  arquivo_consumidor = fopen("consumidores.csv", "r");
  if (arquivo_consumidor != NULL) { //caso arquivo seja diferente de 'nulo' o arquivo passar� por um escaneamento
    while (!feof(arquivo_consumidor)) { //feof retorna um valor diferente de zero se uma opera��o de leitura tentou ler ap�s o final do arquivo.
      fscanf(arquivo_consumidor, "%[^;];%[^;];%[^\n]\n", consumidor_cad.cnpj, //escaneamento "separados" por ponto e v�rgula
        consumidor_cad.nome,
        consumidor_cad.idra);
      if (strcmp(cnpj_consulta, consumidor_cad.cnpj) == 0) { //caso n�o haja nenhuma obje��o, o processo continuar�
        printf("\nAQUI EST�O AS SEGUINTES INFORMA��ES SOLICITADAS.");
        printf("\n\nCNPJ ou CPF do Consumidor: %s\n", consumidor_cad.cnpj); //dados que aparecer�o na STRUCT
        printf("Nome: %s\n", consumidor_cad.nome);
        printf("ID Regi�o Administrativa: %s\n", consumidor_cad.idra);
        encontrei_consumidor = 1;
      }
    }
    if (encontrei_consumidor == 0) { //caso a vari�vel desligue
      printf("\nAVISO!\nN�o foi encontrado(a) nenhum(a) consumidor(a) com o CNPJ: %s.\n", cnpj_consulta);
    }

  } else {
    printf("ERRO, N�O FOI POSS�VEL ABRIR O ARQUIVO.");
  }

  int tamanho = strlen(str);
  int j = 0; //DECLARACAO DE VARIAVEIS PARA A VALIDACAO DE CNPJ
  int icnpj[TAM_CNPJ];
  int i, digito1, digito2, result1, result2, valor, somador = 0;

  for (int i = 0; i < tamanho; i++) {
    if (isdigit(str[i])) { //extra��o de n�meros do cnpj com pontos, barras e tra�os
      cnpj_consulta[j] = str[i];
      j++;
    }
  }
  cnpj_consulta[j] = '\0';

  for (i = 0; i < 14; i++) {
    icnpj[i] = cnpj_consulta[i] - '0'; //come�o da valida��o
  }

  // C�lculo do primeiro d�gito
  somador = icnpj[0] * 5 + icnpj[1] * 4 + icnpj[2] * 3 + icnpj[3] * 2 +
    icnpj[4] * 9 + icnpj[5] * 8 + icnpj[6] * 7 + icnpj[7] * 6 +
    icnpj[8] * 5 + icnpj[9] * 4 + icnpj[10] * 3 + icnpj[11] * 2;

  result1 = somador % 11;
  digito1 = (result1 < 2) ? 0 : 11 - result1;

  // C�lculo do segundo d�gito
  somador = icnpj[0] * 6 + icnpj[1] * 5 + icnpj[2] * 4 + icnpj[3] * 3 +
    icnpj[4] * 2 + icnpj[5] * 9 + icnpj[6] * 8 + icnpj[7] * 7 +
    icnpj[8] * 6 + icnpj[9] * 5 + icnpj[10] * 4 + icnpj[11] * 3 + icnpj[12] * 2;
  valor = (somador / 11) * 11;
  result2 = somador - valor;
  digito2 = (result2 < 2) ? 0 : 11 - result2;

  if (digito1 == icnpj[12] && digito2 == icnpj[13]) {
    printf("CNPJ: v�lido\n\nCaso queira continuar, selecione outra op��o.");
  } else {
    printf("CNPJ: inv�lido!\n\nCaso queira continuar, selecione outra op��o.");
  }
}

void listagem_usina() { //opcao 3
  setlocale(LC_CTYPE, "Portuguese");
  struct usina usina_cad;
  FILE * arquivo_usina;

  arquivo_usina = fopen("miniusinas.csv", "r");
  if (arquivo_usina == NULL) {
    printf("N�o foi poss�vel abrir o arquivo.\n");
    return;
  }

  printf("Voc� selecionou a OP��O 3, 'Listar miniusinas cadastradas'.\n");
  printf("Por favor, aguarde...\n");
  system("pause");
  printf("\n");

  while (fscanf(arquivo_usina, "%[^;];%[^;];%[^;];%[^;];%[^\n]\n", usina_cad.cnpj,
      usina_cad.nome,
      usina_cad.energia,
      usina_cad.idra,
      usina_cad.status) != EOF) {
    ///End Of File
    //n�o h� mais nada para ver no arquivo
    printf("CNPJ: %s\n", usina_cad.cnpj);
    printf("Nome: %s\n", usina_cad.nome);
    printf("Capacidade de Energia: %s\n", usina_cad.energia);
    printf("RA da Usina: %s\n", usina_cad.idra);
    printf("Status: %s\n", usina_cad.status);
    printf("\n");
  }

  // Fecha o arquivo
  fclose(arquivo_usina);

  printf("Deseja continuar? Se sim, por favor, digite outra op��o.\n");
}

void menu_principal() {
  printf("\n|ESCOLHA UMA DAS OP��ES A SEGUIR|\n\n");
  printf("1] Consultar miniusina cadastrada;\n");
  printf("2] Consultar consumidor cadastrado;\n");
  printf("3] Listar miniusinas cadastradas;\n");
  printf("4] Listar as miniusinas em opera��o por ordem descrescente de capacidade de geracao de energia;\n");
  printf("5] Listar as RAs por ordem decrescente de quantidade de miniusinas;\n");
  printf("6] Listar as RAs por ordem crescente de n�meros de contratos;\n");
  printf("7] Listar as RAs por ordem decrescente de capacidade de gera��o;\n");
  printf("8] Listar as RAs por ordem decrescente de percentual de energia dispon�vel;\n");
  printf("9] Sair do programa.\n\n");
}

#endif // 231012254_H
