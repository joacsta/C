/******************************************************************************
Aluno(a): Jo�o Victor Tavares da Costa
Matr�cula: 231012254
Declaro que eu sou o(a) autor(a) deste trabalho e que o c�digo n�o foi copiado
de outra pessoa nem repassado para algu�m. Estou ciente de que poderei sofrer
penaliza��es na avalia��o em caso de detec��o de pl�gio.
*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>
#include "231012254.h"

/*
1) Consultar miniusina cadastrada
2) Consultar consumidor cadastrado
3) Listar as miniusinas cadastradas
4) Listar as miniusinas em opera��o por ordem decrescente de capacidade de gera��o de energia
5) Listar as RAs por ordem decrescente de quantidade de miniusinas
6) Listar as RAs por ordem crescente de n�mero de contratos
7) Listar as RAs por ordem decrescente de capacidade de gera��o
8) Listar as RAs por ordem decrescente de percentual de energia dispon�vel
9) Sair do programa
*/

int main() {
  setlocale(LC_CTYPE, "Portuguese");

  char cpf_ou_cnpj[100];
  int subrespt, respt, resultado; //declaracao de variaveis
  do {
    menu_principal(); //void
    printf("Por favor, selecione uma das op��es: ");
    fflush(stdin);
    resultado = scanf("%d", & respt);
    resultado = 0;

    if (resultado < 0 || resultado > 9) {
      printf("Digita��o inv�lida. ");
    }

    switch (respt) {
    case 1:
      consulta_e_validacao(cpf_ou_cnpj);
      break;

    case 2:
      printf("\nAntes de realizar essa opera��o, preciso que me informe qual o tipo de cadastro ser� digitado.\nSelecione op��o '1', para a OPERA��O COM CNPJ.\nOu selecione op��o '2', para a OPERA��O COM CPF.\nOp��o: ");
      scanf("%d", & subrespt);

      if (subrespt == 1) {
        fgets(cpf_ou_cnpj, sizeof(cpf_ou_cnpj), stdin);
        consumidor_cnpj(cpf_ou_cnpj); ///78.734.354/0001-57TESTE
      } else if (subrespt == 2) {
        fgets(cpf_ou_cnpj, sizeof(cpf_ou_cnpj), stdin);
        consumidor_cpf(cpf_ou_cnpj); ///571.275.906-30 TESTE
      } else {
        printf("\nOP��O INV�LIDA.\n");
      }
      break;

    case 3:
      listagem_usina();
      break;

    case 4:
      opcao4();
      break;

    case 5:
      printf("\nEsta op��o ainda est� em desenvolvimento.\n");
      break;

    case 6:
      printf("\nEsta op��o ainda est� em desenvolvimento.\n");
      break;

    case 7:
      printf("\nEsta op��o ainda est� em desenvolvimento.\n");
      break;

    case 8:
      printf("\nEsta op��o ainda est� em desenvolvimento.\n");
      break;

    case 9:
      printf("\nO sistema foi encerrado.\n");
      break;

    default:
      printf("\nOp��o inv�lida. Tente novamente.\n"); // caso o usuario digite um numero maior que 9.
      system("pause");
    }
  }
  while (respt != 9);

  return 0;
}
