/******************************************************************************
Aluno(a): Jo�o Victor Tavares da Costa
Matr�cula: 231012254
Declaro que eu sou o(a) autor(a) deste trabalho e que o c�digo n�o foi copiado
de outra pessoa nem repassado para algu�m. Estou ciente de que poderei sofrer
penaliza��es na avalia��o em caso de detec��o de pl�gio.
*******************************************************************************/

#include <conio.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>
#include "231012254.h"

int main()
{
    setlocale(LC_CTYPE, "Portuguese");
    char CCC[100];
    int subrespt, respt; //declaracao de variaveis
    do
    {
        menu_principal(); //void
        printf("\nPor favor, selecione uma das op��es: ");
        fflush(stdin);
        scanf("%d", & respt);

        switch (respt)
        {

        case 0:
            limpartela();
            break;

        case 1:
            consulta_e_validacao(CCC);
            break;

        case 2:
            printf("\nOP��O 2, 'Consultar consumidor cadastrado' selecionada.\nAntes de realizar a opera��o, informe qual o tipo de cadastro ser� digitado.\nSelecione '1', para a OPERA��O COM CNPJ.\nOu selecione '2', para a OPERA��O COM CPF.\nCNPJ |1| ou CPF |2|: ");
            scanf("%d", & subrespt);

            if (subrespt == 1)
            {
                fgets(CCC, sizeof(CCC), stdin);
                consumidor_cnpj(CCC);
            }
            else if (subrespt == 2)
            {
                fgets(CCC, sizeof(CCC), stdin);
                consumidor_cpf(CCC);
            }
            else
            {
                printf("\nOP��O INV�LIDA.\n");
            }
            break;

        case 3:
            listagem_usina();
            break;

        case 4:
            ordenacao_energia();
            break;

        case 5:
            lista_qtdMiniusinas();
            break;

        case 6:
            lista_ra_ContratosCrescente();
            break;

        case 7:
            lista_ra_CapEnergia();
            break;

        case 8:
            porcentagem();
            break;

        case 9:
            printf("\nO sistema foi encerrado.\n");
            break;

        default:
            printf("\nOp��o inv�lida. Tente novamente.\n"); // caso o usuario digite um numero maior que 9 ou outro caractere
            getchar();
        }
    }
    while (respt != 9);

    return 0;
}
